# Wandersexpress Website

A responsive static travel-agency website using the supplied Wandersexpress logo.

## Run locally
Open `index.html` in a browser.

## Deploy free
Recommended:
1. Upload this folder to GitHub.
2. Connect the repository to Cloudflare Pages or Netlify.
3. Connect `wandersexpress.com` as the custom domain.
4. Replace placeholder package prices/reviews and any images as needed.

## Contact details configured
+91 85309 33291
+91 87007 71551
wandersexpress@gmail.com
wandersexpress.com
